# Manhattan viewer

This is the first draft of an application to visualise Regenie results in an interactive dashboard

## Installation
This application can be installed with pip, by using the provided `.whl` file, by executing the command `pip install dist/view_manhattan-0.1.0-py3-none-any.whl`

# Usage
